<?php

define('HOST', '3.109.14.4');
define('USER', 'ostechnix');
define('PASSWORD', 'Password123#@!');
define('DATABASE_NAME', 'khanstore');

define('CURRENCY', '₹');
