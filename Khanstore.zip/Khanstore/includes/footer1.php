 
   <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/brands.min.css" integrity="sha512-lCU0XyQA8yobR7ychVxEOU5rcxs0+aYh/9gNDLaybsgW9hdrtqczjfKVNIS5doY0Y5627/+3UVuoGv7p8QsUFw==" crossorigin="anonymous" referrerpolicy="no-referrer" /> -->
 <!-- <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">    -->
<!--     <link rel="stylesheet" href="css/style.css" /> -->
 <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>   -->
    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
   <!--  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>  
 -->
    <!-- <link rel="stylesheet" type="text/css" href="../../Styles.css" /> -->
   <!--  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
    <!-- <link rel="stylesheet" type="text/css" href="../../css/jquery.convform.css" /> -->
  <!--    
  <link rel="stylesheet" type="text/css" href="css/style1.css" />

<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery2.js"></script> -->
<!-- <footer style=" background-color: orange; border-collapse: collapse;
        border: 2px solid navy;
        opacity: 0.7;
        padding: 30px 30px;">
<div class="container">
    <div>
       
        <div class="row">
          <div class="col-xs-4 "><div class="col-lg-3 col-md-6 footer-widget ">
            <img src="../space.jpg" alt="" />

            <div class="social">
              <a href="https://www.facebook.com/SpacECEIn"
                ><i class="fa fa-facebook"></i
              ></a>
              <a href="https://www.instagram.com/spacece.in/"
                ><i class="fa fa-instagram"></i
              ></a>
              <a href="https://t.me/joinchat/EtMJq_3BKL4zNGE1"
                ><i class="fa fa-telegram" aria-hidden="true"></i
              ></a>
              <a href="https://www.linkedin.com/company/spacece-co/"
                ><i class="fa fa-linkedin"></i
              ></a>
            </div></div>
          <div class="col-xs-4">Second</div>
          <div class="col-xs-4">Third</div>
        </div>
</div>
</footer> -->
 <footer
      class="footer-section set-bg"
      style="
        background-color: orange;
        border-collapse: collapse;
        border: 2px solid navy;
        opacity: 0.9;
        padding: 30px 30px;
      ">
   

    



     
         
        <div class="row">
          <div class="col-lg-3 footer-widget ">
            <img src="../img/logo/LibForSmalls.jpeg" class="img img-fluid img-thumbnail img-circle" alt=""  style="width: 150px" />

            <div class="social">
              <a href="https://www.facebook.com/SpacECEIn"
                ><i class="fa fa-facebook"></i
              ></a>
              <a href="https://www.instagram.com/spacece.in/"
                ><i class="fa fa-instagram"></i
              ></a>
              <a href="https://t.me/joinchat/EtMJq_3BKL4zNGE1"
                ><i class="fa fa-telegram" aria-hidden="true"></i
              ></a>
              <a href="https://www.linkedin.com/company/spacece-co/"
                ><i class="fa fa-linkedin"></i
              ></a>
            </div>
          </div>
          <div class="col-lg-3  footer-widget">
            <p style="color: black">
              Still delaying your child's health concerns ?
            </p>
            <p style="color: black">Connect with India's top doctors online</p>
          </div>
          <div class="col-lg-3  footer-widget">
            <div class="contact-widget">
              <h5 class="fw-title text-center" style="color: black">
                CONTACT US
              </h5>
              <p style="color: black">
                <a href="http://www.spacece.in/" style="color: black">
                  <i class="fa fa-map-marker"></i>
                  SPACE-ECE
                </a>
              </p>
              <p style="color: black">
                <a
                  href="tel: +919096305648"
                  target="_blank"
                  rel="noopener"
                  style="color: black"
                >
                  <i class="fa fa-phone" style="color: black"></i>
                  +91 90963 05648
                </a>
              </p>
              <p style="color: black">
                <a
                  href="mailto:events@spacece.co"
                  target="_blank"
                  rel="noopener"
                  style="color: black"
                >
                  <i class="fa fa-envelope" style="color: black"></i>
                  contactus@spacece.co
                </a>
              </p>
              <p style="color: black">
                <i class="fa fa-clock-o" style="color: black"></i>
                Mon - Sat, 8AM - 6PM
              </p>
            </div>
          </div>

          <div class="col-lg-3  footer-widget">
            <div class="newslatter-widget">
              <h5 class="fw-title" style="color: black; text-align: center">
                NEWSLETTER
              </h5>
              <p style="color: black">
                Subscribe your email to get the latest news and new offer also
                discount
              </p>
              <form class="footer-newslatter-form">
                <input type="text" placeholder="Email address" />
                <button style="cursor: pointer" type="submit">
                  <i class="fa fa-send"></i>
                </button>
              </form>
            </div>
          </div>
        </div>
      
      
    </footer>
    <p
      class="font_10"
      style="line-height: 1.8em; text-align: center; font-size: 20px"
    >
      <span style="font-size: 20px"
        ><span class="color_15"
          >&copy;2021 by SpacECE INDIA FOUNDATION</span
        ></span
      >
    </p>
    <!--====== Javascripts & Jquery ======-->
 <!--  <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/masonry.pkgd.min.js"></script>
    <script src="js/magnific-popup.min.js"></script>
    <script src="js/main.js"></script>
    <script type="js/jquery.js"></script>
    <script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
  
    <script type="text/javascript" src="js/custom.js"></script>
    <script type="text/javascript" src="js/jquery-1.12.4.js"></script>
    <script type="text/javascript" src="js/jquery-ui.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script> -->