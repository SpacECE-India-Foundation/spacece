<?php
    $amount=10;
    echo 10;
?>